# Cybersecurity Learning Hub - Premium V4 Starter

Ready-to-upload static starter for GitHub Pages.

## Included
- Landing page
- Monitoring dashboard page
- Admin page
- Dark/light mode
- GitHub Pages auto-deploy workflow

## How to use
1. Create a new GitHub repository.
2. Upload all files from this project to the repo root.
3. Push to the `main` branch.
4. In GitHub repo settings, enable **Pages** and set the source to **GitHub Actions**.
5. After push, GitHub will auto-deploy the site.

## Folder structure
- `index.html` - homepage
- `pages/dashboard.html` - monitoring dashboard
- `pages/admin.html` - admin layout
- `assets/css/styles.css` - styling
- `assets/js/app.js` - theme and demo actions
- `.github/workflows/static.yml` - auto deploy to GitHub Pages

## Next upgrade ideas
- Add course details page
- Add quiz page
- Connect contact form backend
- Replace static data with API or CMS
- Reuse frontend for Telegram Mini App
