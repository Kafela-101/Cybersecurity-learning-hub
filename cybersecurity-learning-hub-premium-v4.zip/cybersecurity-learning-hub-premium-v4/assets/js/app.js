(function () {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('cyberhub-theme');

  if (savedTheme === 'light') {
    body.classList.add('light');
    if (themeToggle) themeToggle.textContent = '☀️';
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      body.classList.toggle('light');
      const isLight = body.classList.contains('light');
      themeToggle.textContent = isLight ? '☀️' : '🌙';
      localStorage.setItem('cyberhub-theme', isLight ? 'light' : 'dark');
    });
  }
})();

function showDemoMessage() {
  const target = document.getElementById('demoMessage');
  if (target) {
    target.textContent = 'Demo mode: connect Formspree, Netlify Forms, or your backend later.';
  }
}
